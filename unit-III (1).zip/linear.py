def linearsearchproduct(productlist,targetproduct):
  indices=[]
  for intax,product in enumerate(productlist):
    if product==targetproduct:
      indices.append(intax)
  return indices
products=["shoes","boot","lofer","shoes","sandal","shoes"]
target="shoes"
result=linearsearchproduct(products,target)
print(result)